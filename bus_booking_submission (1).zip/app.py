import streamlit as st

st.set_page_config(page_title="Smart Bus Reservation System", page_icon="🚌", layout="wide")

st.title("🚌 Smart Bus Reservation System")
st.write("Book bus tickets, search routes, check seats, and view booking reports.")

CITIES = ["Karachi", "Hyderabad", "Sukkur", "Mirpur Khas", "Lahore"]
DEFAULT_ROUTES = [
    {"route_id": "R101", "departure_city": "Karachi", "destination_city": "Hyderabad", "departure_time": "08:00 AM", "ticket_price": 1200, "total_seats": 40},
    {"route_id": "R102", "departure_city": "Karachi", "destination_city": "Sukkur", "departure_time": "09:30 AM", "ticket_price": 2000, "total_seats": 36},
    {"route_id": "R103", "departure_city": "Hyderabad", "destination_city": "Mirpur Khas", "departure_time": "11:00 AM", "ticket_price": 800, "total_seats": 32},
    {"route_id": "R104", "departure_city": "Karachi", "destination_city": "Lahore", "departure_time": "07:00 PM", "ticket_price": 5000, "total_seats": 45},
    {"route_id": "R105", "departure_city": "Sukkur", "destination_city": "Hyderabad", "departure_time": "02:00 PM", "ticket_price": 1500, "total_seats": 30},
]

# Keep app data in Streamlit session state.
if "bus_routes" not in st.session_state:
    st.session_state.bus_routes = [
        {**r, "available_seats": r["total_seats"]} for r in DEFAULT_ROUTES
    ]
if "bus_bookings" not in st.session_state:
    st.session_state.bus_bookings = []
if "next_booking_id" not in st.session_state:
    st.session_state.next_booking_id = 1001

routes = st.session_state.bus_routes
bookings = st.session_state.bus_bookings


def find_route(route_id):
    return next((r for r in routes if r["route_id"] == route_id), None)


def format_money(amount):
    return f"Rs. {amount:,}"


def route_status(route):
    if route["available_seats"] == 0:
        return "Fully booked"
    if route["available_seats"] == route["total_seats"]:
        return "Available"
    return "Partially booked"


def show_routes(route_list):
    if not route_list:
        st.info("No matching routes found.")
        return
    rows = []
    for route in route_list:
        rows.append({
            "Route ID": route["route_id"],
            "From": route["departure_city"],
            "To": route["destination_city"],
            "Departure": route["departure_time"],
            "Price": format_money(route["ticket_price"]),
            "Seats left": f'{route["available_seats"]}/{route["total_seats"]}',
            "Status": route_status(route),
        })
    st.dataframe(rows, use_container_width=True, hide_index=True)


tabs = st.tabs([
    "Routes", "Search", "Book Ticket", "Booking History",
    "Cancel Booking", "Seat Availability", "Reports", "Schedule"
])

with tabs[0]:
    st.subheader("Available Bus Routes")
    show_routes(routes)

with tabs[1]:
    st.subheader("Search Routes")
    search_term = st.text_input("Enter route ID or city", placeholder="For example: R101 or Karachi")
    if st.button("Search routes"):
        term = search_term.strip().casefold()
        if not term:
            st.warning("Please enter a route ID or city name.")
        else:
            found = [
                r for r in routes
                if term == r["route_id"].casefold()
                or term == r["departure_city"].casefold()
                or term == r["destination_city"].casefold()
            ]
            show_routes(found)

with tabs[2]:
    st.subheader("Book a Ticket")
    route_ids = [r["route_id"] for r in routes]
    selected_id = st.selectbox(
        "Select route",
        route_ids,
        format_func=lambda rid: (
            f'{rid} | {find_route(rid)["departure_city"]} → '
            f'{find_route(rid)["destination_city"]} | '
            f'{format_money(find_route(rid)["ticket_price"])}'
        ),
    )
    selected_route = find_route(selected_id)

    if selected_route["available_seats"] == 0:
        st.error("This route is fully booked. Please choose another route.")
    else:
        with st.form("ticket_booking_form"):
            passenger_name = st.text_input("Passenger name")
            passenger_age = st.number_input("Passenger age", min_value=1, max_value=120, value=18, step=1)
            seats = st.number_input(
                "Number of seats",
                min_value=1,
                max_value=selected_route["available_seats"],
                value=1,
                step=1,
            )
            submitted = st.form_submit_button("Confirm Booking")

        if submitted:
            if not passenger_name.strip():
                st.error("Please enter the passenger name.")
            elif int(seats) > selected_route["available_seats"]:
                st.error("There are not enough seats available.")
            else:
                booking_id = f'B{st.session_state.next_booking_id}'
                st.session_state.next_booking_id += 1
                total_fare = selected_route["ticket_price"] * int(seats)
                bookings.append({
                    "booking_id": booking_id,
                    "passenger_name": passenger_name.strip(),
                    "passenger_age": int(passenger_age),
                    "route_id": selected_id,
                    "seats": int(seats),
                    "total_fare": total_fare,
                    "status": "Confirmed",
                })
                selected_route["available_seats"] -= int(seats)
                st.success(f"Booking confirmed! Your booking ID is **{booking_id}**.")
                st.write(f"**Passenger:** {passenger_name.strip()}")
                st.write(f"**Journey:** {selected_route['departure_city']} → {selected_route['destination_city']}")
                st.write(f"**Departure:** {selected_route['departure_time']}")
                st.write(f"**Seats booked:** {int(seats)}")
                st.write(f"**Total fare:** {format_money(total_fare)}")

with tabs[3]:
    st.subheader("Booking History")
    if not bookings:
        st.info("No bookings yet. Make a booking first.")
    else:
        rows = []
        for b in bookings:
            r = find_route(b["route_id"])
            journey = f'{r["departure_city"]} → {r["destination_city"]}' if r else b["route_id"]
            rows.append({
                "Booking ID": b["booking_id"],
                "Passenger": b["passenger_name"],
                "Age": b["passenger_age"],
                "Journey": journey,
                "Seats": b["seats"],
                "Total fare": format_money(b["total_fare"]),
                "Status": b["status"],
            })
        st.dataframe(rows, use_container_width=True, hide_index=True)

with tabs[4]:
    st.subheader("Cancel a Booking")
    confirmed_bookings = [b for b in bookings if b["status"] == "Confirmed"]
    if not confirmed_bookings:
        st.info("There are no confirmed bookings to cancel.")
    else:
        booking_ids = [b["booking_id"] for b in confirmed_bookings]
        booking_to_cancel = st.selectbox("Select booking ID to cancel", booking_ids)
        if st.button("Cancel selected booking", type="primary"):
            booking = next(b for b in bookings if b["booking_id"] == booking_to_cancel)
            route = find_route(booking["route_id"])
            if route:
                route["available_seats"] = min(
                    route["total_seats"], route["available_seats"] + booking["seats"]
                )
            booking["status"] = "Cancelled"
            st.success(f"Booking {booking_to_cancel} cancelled. Seats have been restored.")

with tabs[5]:
    st.subheader("Seat Availability")
    rows = [{
        "Route ID": r["route_id"],
        "Journey": f'{r["departure_city"]} → {r["destination_city"]}',
        "Available seats": r["available_seats"],
        "Total seats": r["total_seats"],
        "Status": route_status(r),
    } for r in routes]
    st.dataframe(rows, use_container_width=True, hide_index=True)

with tabs[6]:
    st.subheader("Booking Reports")
    confirmed = [b for b in bookings if b["status"] == "Confirmed"]
    cancelled = [b for b in bookings if b["status"] == "Cancelled"]
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total bookings", len(bookings))
    col2.metric("Confirmed", len(confirmed))
    col3.metric("Cancelled", len(cancelled))
    col4.metric("Seats reserved", sum(b["seats"] for b in confirmed))
    st.metric("Confirmed revenue", format_money(sum(b["total_fare"] for b in confirmed)))

    report_rows = []
    for r in routes:
        route_bookings = [b for b in confirmed if b["route_id"] == r["route_id"]]
        report_rows.append({
            "Route ID": r["route_id"],
            "Journey": f'{r["departure_city"]} → {r["destination_city"]}',
            "Seats booked": sum(b["seats"] for b in route_bookings),
            "Revenue": format_money(sum(b["total_fare"] for b in route_bookings)),
        })
    st.markdown("#### Route-wise report")
    st.dataframe(report_rows, use_container_width=True, hide_index=True)

with tabs[7]:
    st.subheader("Route Schedule")
    for city in CITIES:
        departures = [r for r in routes if r["departure_city"] == city]
        with st.expander(city):
            if departures:
                for r in departures:
                    st.write(f'**{r["route_id"]}** → {r["destination_city"]} | Departure: {r["departure_time"]}')
            else:
                st.write("No scheduled departures.")

st.divider()
st.caption(
    "Demo note: bookings and seat counts are stored in the current session. "
    "They may reset when the app session restarts."
)
