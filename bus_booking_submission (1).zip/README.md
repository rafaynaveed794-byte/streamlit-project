# Smart Bus Reservation System

A Streamlit app for viewing bus routes, searching routes, booking tickets, cancelling bookings, checking seat availability, and viewing reports.

## Run locally
```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Deploy on Streamlit Community Cloud
- Repository: select the GitHub repository containing these files
- Branch: `main` (or the branch that actually exists in your repository)
- Main file path: `app.py`

Note: this demo stores bookings in Streamlit session state. Data may reset when the app session restarts.
